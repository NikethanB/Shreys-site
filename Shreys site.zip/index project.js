var name = "Shrey"
name = "Made By Shrey Kumar"
alert(name)